package clases;

public class Pedido {
    public String idPedido;
    private int cantidad;
    public float total;
    public String estado; // Reservado Cancelado
    public String idCliente;
    public String idProducto;

    public Pedido(String idPedido, int cantidad, float total, String estado, String idCliente, String idProducto) {
        this.idPedido = idPedido;
        this.cantidad = cantidad;
        this.total = total;
        this.estado = estado;
        this.idCliente = idCliente;
        this.idProducto = idProducto;
    }

    public String getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(String idProducto) {
		this.idProducto = idProducto;
	}

	public String getIdCliente() {
		return idCliente;
	}

	public void setIdCliente(String idCliente) {
		this.idCliente = idCliente;
	}

	public String getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(String idPedido) {
        this.idPedido = idPedido;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }  
    
     @Override
    public String toString() {
        return "Pedido{" +
                "idPedido='" + idPedido + '\'' +
                ", cantidad=" + cantidad +
                ", total=" + total + 
                ", estado='" + estado + '\'' +
                ", idCliente=" + idCliente + 
                ", idProducto=" + idProducto +
                '}';
    }
}
