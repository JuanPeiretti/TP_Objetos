package clases;

public class MetodoPago {
    private String tipoPago; // "debito", "credito", "efectivo"
    public float precioTotal;
    public int cuotas; // 2, 3, 6
    public String idVenta; 
    
    public MetodoPago(String tipoPago, float precioTotal, int cuotas, String idVenta) {
        this.tipoPago = tipoPago;
        this.precioTotal = precioTotal;
        this.cuotas = cuotas;
        this.idVenta = idVenta;
    }
    
    public String getidVenta() {
    	return idVenta;
    }
    
    public void setidVenta(String idVenta) {
    	this.idVenta = idVenta;
    }

    public String getTipoPago() {
        return tipoPago;
    }

    public void setTipoPago(String tipoPago) {
        this.tipoPago = tipoPago;
    }

    public float getPrecioTotal() {
        return precioTotal;
    }

    public void setPrecioTotal(float precioTotal) {
        this.precioTotal = precioTotal;
    }

    public int getCuotas() {
        return cuotas;
    }

    public void setCuotas(int cuotas) {
        this.cuotas = cuotas;
    }   
}
