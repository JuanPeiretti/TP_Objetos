package clases;
	
	
	
public class Autoparte {

	public String IdProducto;
	public String Denominacion;
	public String Descripcion;
	public String Categoria;
	public String marca;
	public String Modelo;
	public float Precio;
	public int Stock;
	public int StockMinimo;
	
	

	public Autoparte(String idProducto, String denominacion, String descripcion,
			String categoria, String marca, String modelo, float precio, int stock, int stockMinimo) {
		super();
		IdProducto = idProducto;
		Denominacion = denominacion;
		Descripcion = descripcion;
		Categoria = categoria;
		this.marca = marca;
		Modelo = modelo;
		Precio = precio;
		Stock = stock;
		StockMinimo = stockMinimo;
	}



	public String getIdProducto() {
		return IdProducto;
	}



	public void setIdProducto(String idProducto) {
		IdProducto = idProducto;
	}




	public String getDenominacion() {
		return Denominacion;
	}



	public void setDenominacion(String denominacion) {
		Denominacion = denominacion;
	}



	public String getDescripcion() {
		return Descripcion;
	}



	public void setDescripcion(String descripcion) {
		Descripcion = descripcion;
	}



	public String getCategoria() {
		return Categoria;
	}



	public void setCategoria(String categoria) {
		Categoria = categoria;
	}



	public String getMarca() {
		return marca;
	}



	public void setMarca(String marca) {
		this.marca = marca;
	}



	public String getModelo() {
		return Modelo;
	}



	public void setModelo(String modelo) {
		Modelo = modelo;
	}



	public float getPrecio() {
		return Precio;
	}



	public void setPrecio(float precio) {
		Precio = precio;
	}



	public int getStock() {
		return Stock;
	}



	public void setStock(int stock) {
		Stock = stock;
	}



	public int getStockMinimo() {
		return StockMinimo;
	}



	public void setStockMinimo(int stockMinimo) {
		StockMinimo = stockMinimo;
	}


	@Override
	public String toString() {
		return "Autoparte [IdProducto=" + IdProducto + ", Denominacion=" + Denominacion + ", Descripcion=" + Descripcion
				+ ", Categoria=" + Categoria + ", marca=" + marca + ", Modelo=" + Modelo + ", Precio=" + Precio
				+ ", Stock=" + Stock + ", StockMinimo=" + StockMinimo + "]";
	}



	public boolean VerificarStockMinimo() {
		// TODO Auto-generated method stub
		return false;
	}
	
	

}
