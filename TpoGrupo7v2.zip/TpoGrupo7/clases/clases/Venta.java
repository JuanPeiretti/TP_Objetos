package clases;
import java.util.Scanner;

public class Venta {
    private String idVenta;
    public String metodoPago;
    public float precioTotal;
    public String idPedido; // Cambio a String para almacenar solo el ID del pedido
    private int cantidad;
    public String idCliente;
    public String idProducto;

    public Venta(String idVenta, String metodoPago, float precioTotal, String idPedido, int cantidad, String idCliente, String idProducto) {
        this.idVenta = idVenta;
        this.metodoPago = metodoPago;
        this.precioTotal = precioTotal;
        this.idPedido = idPedido; // Asignación del ID del pedido
        this.cantidad = cantidad;
        this.idCliente = idCliente;
        this.idProducto = idProducto;
    }

    // Getters y setters para idVenta, metodoPago, precioTotal, idPedido

    public String getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(String idProducto) {
		this.idProducto = idProducto;
	}

	public String getIdCliente() {
		return idCliente;
	}

	public void setIdCliente(String idCliente) {
		this.idCliente = idCliente;
	}

	public String getIdVenta() {
        return idVenta;
    }

    public void setIdVenta(String idVenta) {
        this.idVenta = idVenta;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }

    public float getPrecioTotal() {
        return precioTotal;
    }

    public void setPrecioTotal(float precioTotal) {
        this.precioTotal = precioTotal;
    }

    public String getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(String idPedido) {
        this.idPedido = idPedido;
    }
    
    public int getCantidad() {
    	return cantidad;
    }
    
    public void setCantidad(int cantidad) {
    	this.cantidad = cantidad;
    }
    
    
    @Override
    public String toString() {
        return "Venta{" +
                "idVenta='" + idVenta + '\'' +
                ", metodoPago=" + metodoPago + '\'' +
                ", precioTotal=" + precioTotal + 
                ", idPedido='" + idPedido + '\'' +
                ", cantidad=" + cantidad + 
                ", idCliente=" + idCliente +
                ", idProducto=" + idProducto +
                '}';
    }   
   
    // Método para aplicar las reglas de pago según el método elegido
    public void aplicarPago(Scanner scanner) {
        switch (metodoPago.toLowerCase()) {
            case "debito":
                // En caso de débito, se cobra el valor total de la venta
                System.out.println("Cobrando el valor total de la venta.");
                break;
            case "efectivo":
                // En caso de efectivo, se aplica un descuento del 10%
                float descuentoEfectivo = precioTotal * 0.1f;
                precioTotal -= descuentoEfectivo;
                System.out.println("Aplicando descuento del 10% en efectivo.");
                break;
            case "credito":
                // En caso de crédito, se calcula el recargo según las cuotas
                aplicarRecargoCredito(scanner);
                break;
            default:
                System.out.println("Método de pago no reconocido.");
                break;
        }
    }
      
    // Método para aplicar recargo en pagos con tarjeta de crédito
    public void aplicarRecargoCredito(Scanner scanner) {
        System.out.print("Ingrese la cantidad de cuotas (2, 3 o 6): ");
        int cuotas = Integer.parseInt(scanner.nextLine());
        float recargo = 0;

        switch (cuotas) {
            case 2:
                recargo = precioTotal * 0.06f;
                break;
            case 3:
                recargo = precioTotal * 0.12f;
                break;
            case 6:
                recargo = precioTotal * 0.20f;
                break;
            default:
                System.out.println("Cantidad de cuotas no válida.");
                return;
        }

        precioTotal += recargo;
        System.out.println("Aplicando recargo del " + (recargo * 100 / precioTotal) + "% para " + cuotas + " cuotas.");
    } 



}

