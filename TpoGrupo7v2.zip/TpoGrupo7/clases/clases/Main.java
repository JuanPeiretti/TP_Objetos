package clases;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    private static GestorEmpresa gestor = new GestorEmpresa();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int option;
        Autoparte autoparte1 = new Autoparte( "1", "a", "a", "a", "a", "a" , 10.00f, 100, 15);
        Cliente cliente1 = new Cliente("1", "Kevin", "Alajarin", "JoseMarmol", 111111);
        Cliente cliente2 = new Cliente("2", "Juan", "Peiretti", "das", 123);
        Pedido pedido1 = new Pedido("1", 1, 15, "Reservado", "1", "1") ;
        Venta venta1 = new Venta("1", "Debito", 10.00f, "", 1, "1", "1");
        gestor.getPedidos().add(pedido1);
        gestor.getAutopartes().add(autoparte1);
        gestor.getClientes().add(cliente1);
        gestor.getClientes().add(cliente2);
        gestor.getVentas().add(venta1);
        do {
            showMenu();
            try {
                option = Integer.parseInt(scanner.nextLine());
                switch (option) {
                    case 1:
                        manageCatalog();
                        break;
                    case 2:
                        manageUser();
                        break;
                    case 3:
                        manageOrder();
                        break;
                    case 4:
                        manageSale();
                        break;
                    case 5:
                    	listStockMinimo();
                    	break;
                    case 6:
                    	listaPedidos();
                    	break;
                    case 0:
                        System.out.println("Saliendo...");
                        System.out.print("");
                        break;
                    default:
                        System.out.println("Opción no válida.");
                        System.out.print("");
                }
            } catch (NumberFormatException e) {
                System.out.println("Entrada no válida. Por favor, ingrese un número.");
                System.out.print("");
                option = -1;
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                System.out.print("");
                option = -1;
            }
        } while (option != 0);
    }

    private static void showMenu() {
        System.out.println("---- Menu ----");
        System.out.println("1. Catálogo de autopartes");
        System.out.println("2. Clientes");
        System.out.println("3. Pedidos");
        System.out.println("4. Ventas");
        System.out.println("5. Listar productos con stock mínimo");
        System.out.println("6. Listado de pedidos de un cliente");
        System.out.println("0. Salir");
        System.out.print("Seleccione una opción: ");
        System.out.print("");
    }

    private static void manageCatalog() {
        int option;
        do {
            System.out.println("---- Catálogo de Autopartes ----");
            System.out.println("1. Cargar autoparte");
            System.out.println("2. Modificar autoparte");
            System.out.println("3. Listar autopartes");
            System.out.println("4. Bajar autoparte");
            System.out.println("5. Modificar stock de autoparte");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            System.out.print("");
            try {
                option = Integer.parseInt(scanner.nextLine());
                switch (option) {
                    case 1:
                        cargarAutoparte();
                        break;
                    case 2:
                        modificarAutoparte();
                        break;
                    case 3:
                        gestor.listadoDeProductos();
                        break;
                    case 4:
                        bajarAutoparte();
                        break;
                    case 5:
                        modificarStockAutoparte();
                        break;
                    case 0:
                        System.out.println("Volviendo al menú principal...");
                        System.out.println("");
                        break;
                    default:
                        System.out.println("Opción no válida.");
                        System.out.print("");
                }
            } catch (NumberFormatException e) {
                System.out.println("Entrada no válida. Por favor, ingrese un número.");
                System.out.print("");
                option = -1;
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                option = -1;
            }
        } while (option != 0);
    }

    private static void cargarAutoparte() {
        try {
            String idProducto;
            Autoparte autoparteExistente;

            do {
                System.out.print("Ingrese el código: ");
                idProducto = scanner.nextLine();

                // Verificar si ya existe una autoparte con el mismo código
                autoparteExistente = gestor.buscarautoparte(idProducto);
                if (autoparteExistente != null) {
                    System.out.println("Ya existe una autoparte con el código ingresado. Por favor, ingrese otro código.");
                }
            } while (autoparteExistente != null);

            System.out.print("Ingrese la denominación: ");
            String denominacion = scanner.nextLine();
            System.out.print("Ingrese la descripción: ");
            String descripcion = scanner.nextLine();
            System.out.print("Ingrese la categoría: ");
            String categoria = scanner.nextLine();
            System.out.print("Ingrese la marca: ");
            String marca = scanner.nextLine();
            System.out.print("Ingrese el modelo: ");
            String modelo = scanner.nextLine();
            System.out.print("Ingrese el precio unitario: ");
            float precio = Float.parseFloat(scanner.nextLine());
            System.out.print("Ingrese la cantidad en stock: ");
            int stock = Integer.parseInt(scanner.nextLine());
            System.out.print("Ingrese el stock mínimo: ");
            int stockMinimo = Integer.parseInt(scanner.nextLine());
            
            Autoparte autoparte = new Autoparte(idProducto, denominacion, descripcion, categoria, marca, modelo, precio, stock, stockMinimo);
            gestor.getAutopartes().add(autoparte);

            System.out.println("Autoparte cargada con éxito.");
            System.out.print("");

        } catch (NumberFormatException e) {
            System.out.println("Error al ingresar valores numéricos: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error al cargar la autoparte: " + e.getMessage());
        }
    }

    
    private static void modificarAutoparte() {
        try {
            System.out.print("Ingrese el código de la autoparte a modificar: ");
            String idProducto = scanner.nextLine();

            // Buscar la autoparte por su código para mostrar la información actual
            Autoparte autoparteActual = gestor.buscarautoparte(idProducto);
            if (autoparteActual == null) {
                System.out.println("Autoparte no encontrada.");
                System.out.print("");
                return;
            }

            // Mostrar la información actual de la autoparte
            System.out.println("Información actual de la autoparte:");
            System.out.println("Código: " + autoparteActual.getIdProducto());
            System.out.println("Denominación: " + autoparteActual.getDenominacion());
            System.out.println("Descripción: " + autoparteActual.getDescripcion());
            System.out.println("Categoría: " + autoparteActual.getCategoria());
            System.out.println("Marca: " + autoparteActual.getMarca());
            System.out.println("Modelo: " + autoparteActual.getModelo());
            System.out.println("Precio Unitario: " + autoparteActual.getPrecio());
            System.out.println("Stock: " + autoparteActual.getStock());
            System.out.println("Stock Mínimo: " + autoparteActual.getStockMinimo());
            System.out.print("");

            // Proceso de modificación
            boolean modificado = false;
            do {
                System.out.print("¿Qué desea modificar? (Denominacion / Descripcion / Categoria / Marca / Modelo / Precio / Stock / StockMinimo): ");
                String opcion = scanner.nextLine();

                switch (opcion.toLowerCase()) {
                    case "denominación":
                        System.out.print("Ingrese la nueva denominación: ");
                        String nuevaDenominacion = scanner.nextLine();
                        autoparteActual.setDenominacion(nuevaDenominacion);
                        modificado = true;
                        break;
                    case "descripción":
                        System.out.print("Ingrese la nueva descripción: ");
                        String nuevaDescripcion = scanner.nextLine();
                        autoparteActual.setDescripcion(nuevaDescripcion);
                        modificado = true;
                        break;
                    case "categoría":
                        System.out.print("Ingrese la nueva categoría: ");
                        String nuevaCategoria = scanner.nextLine();
                        autoparteActual.setCategoria(nuevaCategoria);
                        modificado = true;
                        break;
                    case "marca":
                        System.out.print("Ingrese la nueva marca: ");
                        String nuevaMarca = scanner.nextLine();
                        autoparteActual.setMarca(nuevaMarca);
                        modificado = true;
                        break;
                    case "modelo":
                        System.out.print("Ingrese el nuevo modelo: ");
                        String nuevoModelo = scanner.nextLine();
                        autoparteActual.setModelo(nuevoModelo);
                        modificado = true;
                        break;
                    case "precio":
                        System.out.print("Ingrese el nuevo precio unitario: ");
                        float nuevoPrecio = Float.parseFloat(scanner.nextLine());
                        autoparteActual.setPrecio(nuevoPrecio);
                        modificado = true;
                        break;
                    case "stock":
                        System.out.print("Ingrese la nueva cantidad en stock: ");
                        int nuevoStock = Integer.parseInt(scanner.nextLine());
                        autoparteActual.setStock(nuevoStock);
                        modificado = true;
                        break;
                    case "stock minimo":
                        System.out.print("Ingrese el nuevo stock mínimo: ");
                        int nuevoStockMinimo = Integer.parseInt(scanner.nextLine());
                        autoparteActual.setStockMinimo(nuevoStockMinimo);
                        modificado = true;
                        break;
                    default:
                        System.out.println("Opción no válida.");
                        System.out.print("");
                        break;
                }
            } while (!modificado);

            // Aplicar los cambios a la autoparte
            gestor.modificacionDeProducto(idProducto, autoparteActual);
            System.out.println("Autoparte modificada con éxito.");
            System.out.print("");

        } catch (NumberFormatException e) {
            System.out.println("Entrada no válida. Por favor, ingrese un número válido.");
            System.out.print("");
        } catch (Exception e) {
            System.out.println("Ocurrió un error al modificar la autoparte: " + e.getMessage());
            System.out.print("");
        }
    }
    
    private static void bajarAutoparte() {
        try {
            System.out.print("Ingrese el código de la autoparte a dar de baja: ");
            String idProducto = scanner.nextLine();
            gestor.bajaDeProductos(idProducto);
            System.out.println("Autoparte dada de baja con éxito.");
            System.out.print("");
        } catch (Exception e) {
            System.out.println("Ocurrió un error al dar de baja la autoparte: " + e.getMessage());
            System.out.print("");
        }
    }

    private static void modificarStockAutoparte() {
    	try {
    		System.out.print("Ingrese el código de la autoparte: ");
    		String idProducto = scanner.nextLine();
    		Autoparte autoparte = gestor.buscarautoparte(idProducto);
    		if (autoparte == null) {
    			System.out.println("Autoparte no encontrada");
    	        System.out.print("");
    			return;
    		}
    		
    		System.out.print("Ingrese la nueva cantidad en stock: ");
    		int nuevoStock = Integer.parseInt(scanner.nextLine());
    		autoparte.setStock(nuevoStock);
    		System.out.println("Stock modificado");  	     
            System.out.print("");
    	} catch (NumberFormatException e) {
    		System.out.println("Entrada no valida. Porfavor, ingrese un numero");
            System.out.print("");
    	} catch (Exception e) {
    		System.out.println("Error: " + e.getMessage());
            System.out.print("");
    	}
    }
    
    private static void manageUser() {
        int option;
        do {
            System.out.println("---- Catálogo de Usuarios ----");
            System.out.println("1. Cargar usuario");
            System.out.println("2. Modificar usuario");
            System.out.println("3. Listar usuarios");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            System.out.print("");
            try {
                option = Integer.parseInt(scanner.nextLine());
                switch (option) {
                    case 1:
                        registerUser();
                        break;
                    case 2:
                        modificarUser();
                        break;
                    case 3:
                        gestor.listadoDeUsers();
                        break;
                    case 0:
                        System.out.println("Volviendo al menú principal...");
                        System.out.print("");
                        break;
                    default:
                        System.out.println("Opción no válida.");
                        System.out.print("");
                }
            } catch (NumberFormatException e) {
                System.out.println("Entrada no válida. Por favor, ingrese un número.");
                System.out.print("");
                option = -1;
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                System.out.print("");
                option = -1;
            }
        } while (option != 0);
    }
    
    private static void registerUser() {
        try {
            String idCliente;
            Cliente clienteExistente;

            do {
                System.out.print("Ingrese el ID del cliente: ");
                idCliente = scanner.nextLine();

                // Verificar si ya existe un cliente con el mismo ID
                clienteExistente = gestor.buscarCliente(idCliente);
                if (clienteExistente != null) {
                    System.out.println("Ya existe un cliente con el ID ingresado. Por favor, ingrese otro ID.");
                }
            } while (clienteExistente != null);

            System.out.print("Ingrese el nombre del cliente: ");
            String nombre = scanner.nextLine();
            System.out.print("Ingrese el apellido del cliente: ");
            String apellido = scanner.nextLine();
            System.out.print("Ingrese la dirección del cliente: ");
            String direccion = scanner.nextLine();
            System.out.print("Ingrese el teléfono del cliente: ");
            int telefono = Integer.parseInt(scanner.nextLine());

            Cliente cliente = new Cliente(idCliente, nombre, apellido, direccion, telefono);
            gestor.getClientes().add(cliente);

            System.out.println("Cliente registrado con éxito.");
            System.out.print("");

        } catch (NumberFormatException e) {
            System.out.println("Entrada no válida. Por favor, ingrese un número para el teléfono.");
            System.out.print("");
        } catch (Exception e) {
            System.out.println("Ocurrió un error al registrar el cliente: " + e.getMessage());
            System.out.print("");
        }
    }

        
    private static void modificarUser() {
        try {
            System.out.print("Ingrese el ID del cliente a modificar: ");
            String idCliente = scanner.nextLine();

            // Buscar al cliente por su ID para mostrar la información actual
            Cliente clienteActual = gestor.buscarCliente(idCliente);
            if (clienteActual == null) {
                System.out.println("Cliente no encontrado.");
                System.out.print("");
                return;
            }

            // Mostrar la información actual del cliente
            System.out.println("Información actual del cliente:");
            System.out.println("ID Cliente: " + clienteActual.getIdCliente());
            System.out.println("Nombre: " + clienteActual.getNombre());
            System.out.println("Apellido: " + clienteActual.getApellido());
            System.out.println("Dirección: " + clienteActual.getDireccion());
            System.out.println("Teléfono: " + clienteActual.getTelefono());
            System.out.print("");

            // Proceso de modificación
            boolean modificado = false;
            do {
                System.out.print("¿Qué desea modificar? (Nombre / Apellido / Direccion / Telefono): ");
                String opcion = scanner.nextLine();

                switch (opcion.toLowerCase()) {
                    case "nombre":
                        System.out.print("Ingrese el nuevo nombre: ");
                        String nuevoNombre = scanner.nextLine();
                        clienteActual.setNombre(nuevoNombre);
                        modificado = true;
                        break;
                    case "apellido":
                        System.out.print("Ingrese el nuevo apellido: ");
                        String nuevoApellido = scanner.nextLine();
                        clienteActual.setApellido(nuevoApellido);
                        modificado = true;
                        break;
                    case "dirección":
                        System.out.print("Ingrese la nueva dirección: ");
                        String nuevaDireccion = scanner.nextLine();
                        clienteActual.setDireccion(nuevaDireccion);
                        modificado = true;
                        break;
                    case "teléfono":
                        System.out.print("Ingrese el nuevo teléfono: ");
                        int nuevoTelefono = Integer.parseInt(scanner.nextLine());
                        clienteActual.setTelefono(nuevoTelefono);
                        modificado = true;
                        break;
                    default:
                        System.out.println("Opción no válida.");
                        System.out.print("");
                        break;
                }
            } while (!modificado);

            // Aplicar los cambios al cliente
            gestor.modificacionDeUser(idCliente, clienteActual);
            System.out.println("Cliente modificado con éxito.");
            System.out.print("");

        } catch (NumberFormatException e) {
            System.out.println("Entrada no válida. Por favor, ingrese un número válido para el teléfono.");
            System.out.print("");
        } catch (Exception e) {
            System.out.println("Ocurrió un error al modificar el cliente: " + e.getMessage());
            System.out.print("");
        }
    }
    
 
    
    private static void manageOrder() {
        int option;
        do {
            System.out.println("---- Catálogo de Pedidos ----");
            System.out.println("1. Cargar pedido");
            System.out.println("2. Modificar pedido");
            System.out.println("3. Listar pedido");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            System.out.print("");
            try {
                option = Integer.parseInt(scanner.nextLine());
                switch (option) {
                    case 1:
                        registerPedido();
                        break;
                    case 2:
                        modificarPedido();
                        break;
                    case 3:
                        gestor.listadoDePedidos();
                        break;
                    case 0:
                        System.out.println("Volviendo al menú principal...");
                        System.out.print("");
                        break;
                    default:
                        System.out.println("Opción no válida.");
                        System.out.print("");
                }
            } catch (NumberFormatException e) {
                System.out.println("Entrada no válida. Por favor, ingrese un número.");
                System.out.print("");
                option = -1;
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                System.out.print("");
                option = -1;
            }
        } while (option != 0);
    }
    
    private static void registerPedido() {
    	try {
    		// Solicitar ID cliente
    		System.out.print("Ingrese el id del Cliente: ");
    		String idCliente = scanner.nextLine();
    		// Buscar cliente en el gestor
    		Cliente cliente = gestor.buscarCliente(idCliente);
            if (cliente == null) {
                System.out.println("Cliente no encontrado.");
                System.out.print("");
                return;
            }
    		System.out.print("Ingrese el id del pedido: ");
    		String idPedido = scanner.nextLine();
    		
            Pedido pedidoExistente = gestor.buscarPedido(idPedido);
            if (pedidoExistente != null) {
                // Si ya existe, mostrar mensaje y retornar
                System.out.println("Ya existe un pedido con este ID.");
                return;
            }

    		
    		System.out.print("Ingrese el ID de autoparte: ");
    		String idProducto = scanner.nextLine();
    		Autoparte autoparte = gestor.buscarautoparte(idProducto);
    		if (autoparte == null) {
    			System.out.println("Autoparte no encontrado");
    	        System.out.print("");
    			return;
    			}
    		
    		System.out.println("Stock disponible: " + autoparte.getStock());
    		System.out.print("Ingrese la cantidad: ");
    		int cantidad = Integer.parseInt(scanner.nextLine());
    		if (cantidad > autoparte.getStock()) {
    			System.out.println("Stock insuficiente.");
    	        System.out.print("");
    			return;
    		}   		
            Pedido pedido = new Pedido(idPedido, cantidad, cantidad * autoparte.getPrecio(), "Reservado", idCliente, idProducto);
    		float total = cantidad *- autoparte.getPrecio();
    		pedido.setTotal(total);
    		pedido.setEstado("Reservado");
    		
    		gestor.getPedidos().add(pedido);
    		
    		autoparte.setStock(autoparte.getStock() - cantidad);
    		System.out.println("Pedido registrado con exito.");
            System.out.print("");
    	} catch (NumberFormatException e) {
    		System.out.println("Ocurrio un errorr al registrar el pedido: " + e.getMessage());
            System.out.print("");
    	}	  		 	
    }
       
    private static void modificarPedido() {
        try {
            System.out.print("Ingrese el ID del pedido a modificar: ");
            String idPedido = scanner.nextLine();
            Pedido pedido = gestor.buscarPedido(idPedido);
            if (pedido == null) {
                System.out.println("Pedido no encontrado.");
                System.out.print("");
                return;
            }

            // Mostrar detalles actuales del pedido
            System.out.println("Detalles del pedido: ");
            System.out.println("ID Pedido: " + pedido.getIdPedido());
            System.out.println("Cantidad: " + pedido.getCantidad());
            System.out.println("Estado: " + pedido.getEstado());
            System.out.print("");

            String opcion;
            do {
                System.out.print("¿Qué desea modificar? (Cantidad / Estado): ");
                opcion = scanner.nextLine();

                if (opcion.equalsIgnoreCase("Cantidad")) {
                    // Mostrar el stock actual del producto y la cantidad actual del pedido
                    Autoparte autoparte = gestor.buscarautoparte(pedido.getIdProducto());
                    if (autoparte == null) {
                        System.out.println("Autoparte no encontrada.");
                        System.out.print("");
                        return;
                    }
                    System.out.println("Stock disponible: " + autoparte.getStock());
                    System.out.println("Cantidad actual del pedido: " + pedido.getCantidad());

                    // Modificar la cantidad del pedido
                    System.out.print("Ingrese la nueva cantidad: ");
                    int nuevaCantidad = Integer.parseInt(scanner.nextLine());

                    // Verificar que la nueva cantidad no exceda el stock disponible
                    int stockActual = autoparte.getStock();
                    int stockDisponible = stockActual + pedido.getCantidad();

                    if (nuevaCantidad > stockDisponible) {
                        System.out.println("No se puede modificar la cantidad. Stock insuficiente.");
                        System.out.print("");
                        continue; // Volver a preguntar qué desea modificar
                    }

                    // Calcular el cambio en el stock de la autoparte
                    int cambioStock = nuevaCantidad - pedido.getCantidad();
                    autoparte.setStock(stockActual - cambioStock);

                    // Actualizar la cantidad del pedido
                    pedido.setCantidad(nuevaCantidad);
                    System.out.println("Cantidad modificada con éxito.");
                    System.out.print("");

                    // Recalcular el total del pedido
                    float precioUnitario = autoparte.getPrecio();
                    float nuevoTotal = nuevaCantidad * precioUnitario;
                    pedido.setTotal(nuevoTotal);

                    // Aplicar los cambios al pedido en la lista del gestor
                    gestor.modificacionDePedido(idPedido, pedido);

                } else if (opcion.equalsIgnoreCase("Estado")) {
                    // Modificar el estado del pedido
                    System.out.print("Ingrese el nuevo estado (Reservado / Cancelado): ");
                    String nuevoEstado = scanner.nextLine();

                    // Verificar que el estado ingresado sea válido
                    if (!nuevoEstado.equalsIgnoreCase("Reservado") && !nuevoEstado.equalsIgnoreCase("Cancelado")) {
                        System.out.println("Estado no válido.");
                        System.out.print("");
                        continue; // Volver a preguntar qué desea modificar
                    }

                    // Si el estado cambia de Reservado a Cancelado, devolver la cantidad al stock
                    if (pedido.getEstado().equalsIgnoreCase("Reservado") && nuevoEstado.equalsIgnoreCase("Cancelado")) {
                        Autoparte autoparte = gestor.buscarautoparte(pedido.getIdProducto());
                        if (autoparte == null) {
                            System.out.println("Autoparte no encontrada.");
                            System.out.print("");
                            return;
                        }
                        autoparte.setStock(autoparte.getStock() + pedido.getCantidad()); // Devolver la cantidad al stock

                        // Eliminar el pedido de la lista del gestor
                        gestor.eliminarPedido(idPedido);
                        System.out.println("Pedido eliminado con éxito.");
                        System.out.print("");
                        return; // Salir del método después de eliminar el pedido
                    }

                    // Actualizar estado del pedido
                    pedido.setEstado(nuevoEstado);
                    System.out.println("Estado modificado con éxito.");
                    System.out.print("");

                    // Aplicar los cambios al pedido en la lista del gestor
                    gestor.modificacionDePedido(idPedido, pedido);
                } else {
                    System.out.println("Opción no válida.");
                    System.out.print("");
                }

                // Mostrar el pedido actualizado
                System.out.println("Pedido actualizado:");
                System.out.println("ID Pedido: " + pedido.getIdPedido());
                System.out.println("Cantidad: " + pedido.getCantidad());
                System.out.println("Total: " + pedido.getTotal()); // Mostrar el total actualizado
                System.out.println("Estado: " + pedido.getEstado());
                System.out.print("");

            } while (!opcion.equalsIgnoreCase("Cantidad") && !opcion.equalsIgnoreCase("Estado"));

        } catch (NumberFormatException e) {
            System.out.println("Entrada no válida. Por favor, ingrese un número válido.");
            System.out.print("");
        } catch (Exception e) {
            System.out.println("Ocurrió un error al modificar el pedido: " + e.getMessage());
            System.out.print("");
        }
    }

  
    
    private static void manageSale() {
    	int option;
        do {
            System.out.println("---- Catálogo de Ventas ----");
            System.out.println("1. Cargar venta");
            System.out.println("2. Cargar pedido");
            System.out.println("3. Modificar venta");
            System.out.println("4. Listar ventas");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            System.out.print("");
            try {
                option = Integer.parseInt(scanner.nextLine());
                switch (option) {
                    case 1:
                        registerVenta();
                        break;
                    case 2:
                        registerVentaPedido();
                        break;
                    case 3:
                    	  modificarVenta();
                    case 4:
                        gestor.listadoDeVentas();
                        break;
                    case 0:
                        System.out.println("Volviendo al menú principal...");
                        System.out.print("");
                        break;
                    default:
                        System.out.println("Opción no válida.");
                        System.out.print("");
                }
            } catch (NumberFormatException e) {
                System.out.println("Entrada no válida. Por favor, ingrese un número.");
                System.out.print("");
                option = -1;
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                System.out.print("");
                option = -1;
            }
        } while (option != 0);
    }


    
    private static void registerVenta() {
        try {
            System.out.print("Ingrese el id del Cliente: ");
            String idCliente = scanner.nextLine();
            Cliente cliente = gestor.buscarCliente(idCliente);
            if (cliente == null) {
                System.out.println("Cliente no encontrado.");
                System.out.print("");
                return;
            }

            // Solicitar ID de venta
            System.out.print("Ingrese el id de la venta: ");
            String idVenta;
            Venta ventaExistente;

            do {
                idVenta = scanner.nextLine();

                // Verificar si ya existe una venta con ese ID
                ventaExistente = gestor.buscarVenta(idVenta);
                if (ventaExistente != null) {
                    System.out.println("Ya existe una venta con este ID. Por favor, ingrese otro ID.");
                    System.out.print("Ingrese el id de la venta: ");
                }
            } while (ventaExistente != null);

            // Solicitar ID de autoparte
            System.out.print("Ingrese el id de la autoparte: ");
            String idProducto = scanner.nextLine();
            Autoparte autoparte = gestor.buscarautoparte(idProducto);
            if (autoparte == null) {
                System.out.println("Autoparte no encontrada.");
                System.out.print("");
                return;
            }

            System.out.println("Stock disponible: " + autoparte.getStock());
            System.out.print("Ingrese la cantidad: ");
            int cantidad = Integer.parseInt(scanner.nextLine());
            if (cantidad > autoparte.getStock()) {
                System.out.println("Stock insuficiente para la cantidad solicitada.");
                System.out.print("");
                return;
            }

            // Actualizar el stock de la autoparte
            int nuevoStock = autoparte.getStock() - cantidad;
            autoparte.setStock(nuevoStock);

            // Crear objeto Venta y registrarla
            float precioUnitario = autoparte.getPrecio();
            float precioTotal = precioUnitario * cantidad;

            System.out.println("Total sin descuentos: " + precioTotal);

            Venta venta = new Venta(idVenta, "", precioTotal, "", cantidad, idCliente, idProducto);

            System.out.print("Ingrese el método de pago (debito/credito/efectivo): ");
            String metodoPago = scanner.nextLine();

            // Actualizar método de pago y aplicar ajustes
            venta.setMetodoPago(metodoPago);
            venta.aplicarPago(scanner); // Llama al método aplicarPago adecuadamente

            gestor.getVentas().add(venta);
            System.out.println("Venta registrada con éxito.");
            System.out.println("Total con ajustes: " + venta.getPrecioTotal());
            System.out.print("");

        } catch (NumberFormatException e) {
            System.out.println("Ocurrió un error al registrar la venta: " + e.getMessage());
            System.out.print("");
        } catch (Exception e) {
            System.out.println("Ocurrió un error al registrar la venta: " + e.getMessage());
            System.out.print("");
        }
    }



    private static void modificarVenta() {
        try {
            // Solicitar el ID de la venta a modificar
            System.out.print("Ingrese el ID de la venta a modificar: ");
            String idVenta = scanner.nextLine();
            
            // Buscar la venta en el gestor
            Venta venta = gestor.buscarVenta(idVenta);
            if (venta == null) {
                System.out.println("Venta no encontrada.");
                return;
            }
            
            // Mostrar la información actual de la venta
            System.out.println("Información actual de la venta:");
            System.out.println("ID Venta: " + venta.getIdVenta());
            System.out.println("Método de Pago: " + venta.getMetodoPago());
            System.out.println("Precio Total: " + venta.getPrecioTotal());
            System.out.println("Cantidad: " + venta.getCantidad());
            
            // Solicitar al usuario qué campo desea modificar
            System.out.print("¿Qué desea modificar? (Cantidad / MetodoPago): ");
            String campo = scanner.nextLine();
            
            if (campo.equalsIgnoreCase("Cantidad")) {
                // Solicitar la nueva cantidad
                System.out.print("Ingrese id de autoparte: ");
                String idProducto = scanner.nextLine();
                Autoparte autoparte = gestor.buscarautoparte(idProducto);
                if (autoparte == null) {
                    System.out.println("Autoparte no encontrada.");
                    System.out.print("");
                    return;         
                }
                System.out.print("Ingrese la nueva cantidad: ");                
                int nuevaCantidad = Integer.parseInt(scanner.nextLine());
                
                System.out.println("Stock disponible: " + autoparte.getStock());
                
                // Actualizar la cantidad en la venta y recalcular el total
                venta.setCantidad(nuevaCantidad);
                float nuevoTotal = nuevaCantidad * autoparte.getPrecio();
                venta.setPrecioTotal(nuevoTotal);
                
                System.out.println("Cantidad modificada con éxito.");
                System.out.println("Venta actualizada:");
                System.out.println("ID Venta: " + venta.getIdVenta());
                System.out.println("Cantidad: " + venta.getCantidad());
                System.out.println("Precio Total: " + venta.getPrecioTotal());
            } else if (campo.equalsIgnoreCase("MetodoPago")) {
                // Solicitar el nuevo método de pago
                System.out.print("Ingrese el nuevo método de pago (debito/credito/efectivo): ");
                String nuevoMetodoPago = scanner.nextLine();
                
                // Actualizar el método de pago en la venta y aplicar los ajustes necesarios
                venta.setMetodoPago(nuevoMetodoPago);
                venta.aplicarPago(scanner);
                
                System.out.println("Método de pago modificado con éxito.");
                System.out.println("Venta actualizada:");
                System.out.println("ID Venta: " + venta.getIdVenta());
                System.out.println("Cantidad: " + venta.getCantidad());
                System.out.println("Metodo Pago: " + venta.getMetodoPago());
                System.out.println("Precio Total: " + venta.getPrecioTotal());
            } else {
                System.out.println("Campo no válido para modificar.");
            }
        } catch (Exception e) {
            System.out.println("Ocurrió un error al modificar la venta: " + e.getMessage());
        }
    }


    
    private static void registerVentaPedido() {
        try {
            // Solicitar el ID del pedido que se desea convertir en venta
            System.out.print("Ingrese el ID del pedido que desea convertir en venta: ");
            String idPedido = scanner.nextLine();
                            
            // Buscar el pedido en el gestor
            Pedido pedido = gestor.buscarPedido(idPedido);
            if (pedido == null) {
                System.out.println("Pedido no encontrado.");
                System.out.print("");
                return;
            }
            
            System.out.println("Información actual del pedido:");
            System.out.println("ID pedido: " + pedido.getIdPedido());
            System.out.println("Cantidad: " + pedido.getCantidad());
            System.out.println("Precio Total: " + pedido.getTotal());
            System.out.println("Estado: " + pedido.getEstado());
            System.out.println("ID Cliente: " + pedido.getIdCliente());
            System.out.println("ID Producto: " + pedido.getIdProducto());
            
            // Verificar el estado del pedido para permitir su conversión a venta
            if (!pedido.getEstado().equalsIgnoreCase("Reservado")) {
                System.out.println("No se puede convertir el pedido. Estado actual: " + pedido.getEstado());
                System.out.print("");
                return;
            }                  
            
            String idCliente = pedido.getIdCliente();            
            // Crear una nueva venta a partir del pedido
            String idVenta = "Pedido " + idPedido; // Cambiar el ID de venta
                
            int cantidad = pedido.getCantidad();    
            float precioTotal = pedido.getTotal();

            String metodoPago;
            do {
                // Solicitar al usuario que elija el método de pago
                System.out.print("Seleccione el método de pago (debito/credito/efectivo): ");
                metodoPago = scanner.nextLine();

                if (!metodoPago.equalsIgnoreCase("debito") && !metodoPago.equalsIgnoreCase("credito") && !metodoPago.equalsIgnoreCase("efectivo")) {
                    System.out.println("Método de pago no reconocido.");
                }
            } while (!metodoPago.equalsIgnoreCase("debito") && !metodoPago.equalsIgnoreCase("credito") && !metodoPago.equalsIgnoreCase("efectivo"));
            
            Venta venta = new Venta(idVenta, metodoPago, precioTotal, idPedido, cantidad, idCliente, pedido.getIdProducto());
            
            venta.setCantidad(cantidad);
            venta.setMetodoPago(metodoPago);
            venta.aplicarPago(scanner);
            pedido.setEstado("Vendido");
            
            // Registrar la venta en el gestor de ventas
            gestor.getVentas().add(venta);
            
            System.out.println("Venta registrada desde pedido con éxito.");
            System.out.println("Total con ajustes: " + venta.getPrecioTotal());
            System.out.print("");

        } catch (Exception e) {
            System.out.println("Ocurrió un error al registrar la venta desde el pedido: " + e.getMessage());
            System.out.print("");
        }
    }

    
    private static void listStockMinimo() {
        try {
            ArrayList<Autoparte> autopartes = gestor.getAutopartes();
            boolean productosConMenosStockMinimo = false; // Bandera para controlar si se encontraron productos con menos stock mínimo

            System.out.println("Productos con stock igual o menor al stock mínimo:");
            for (Autoparte autoparte : autopartes) {
                if (autoparte.VerificarStockMinimo()) {
                    System.out.println("* " + autoparte); // Marcar con '*' los productos en stock mínimo
                    productosConMenosStockMinimo = true; // Se encontró al menos un producto con menos stock mínimo
                }
            }

            if (!productosConMenosStockMinimo) {
                System.out.println("No hay productos con menos stock mínimo.");
            }

        } catch (Exception e) {
            System.out.println("Ocurrió un error al listar los productos con stock mínimo: " + e.getMessage());
        }
    }
    
    private static void listaPedidos() {
    	
    	System.out.print("Ingrese el ID del Cliente: ");
    	String idCliente = scanner.nextLine();
    	gestor.listadoPedidos(idCliente);
    	
    }
}

            
         




    	    
