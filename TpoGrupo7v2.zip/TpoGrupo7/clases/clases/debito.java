package clases;

public class debito {

}
