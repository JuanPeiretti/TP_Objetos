package clases;

import java.util.ArrayList;

public class GestorEmpresa {
    private ArrayList<Autoparte> autopartes;
    private ArrayList<Cliente> clientes;
    private ArrayList<Pedido> pedidos;
    private ArrayList<Venta> ventas;

    public GestorEmpresa() {
        this.clientes = new ArrayList<>();
        this.pedidos = new ArrayList<>();
        this.ventas = new ArrayList<>();
        this.autopartes = new ArrayList<>();
    }
//-------------------------------------------------------------------------------------------------------------------//
    public ArrayList<Cliente> getClientes() {
        return clientes;
    }
    
    public void setClientes(ArrayList<Cliente> clientes) {
    	this.clientes = clientes;
    }

    public ArrayList<Pedido> getPedidos() {
        return pedidos;
    }
    
    public void setPedidos(ArrayList<Pedido> pedidos) {
    	this.pedidos = pedidos;
    }

    public ArrayList<Venta> getVentas() {
        return ventas;
    }
    
    public void setVentas(ArrayList<Venta> ventas) {
    	this.ventas = ventas;
    }
    
    public ArrayList<Autoparte> getAutopartes() {
    	return autopartes;
    }
    
    public void setAutopartes(ArrayList<Autoparte> autopartes) {
    	this.autopartes = autopartes;
    }
    
  //-------------------------------------------------------------------------------------------------------------------//
    public void listadoDeProductos() {
        for (Autoparte producto : autopartes) {
            System.out.println(producto);
        }
    }
    
    public Autoparte buscarautoparte(String idProducto) {
        ArrayList<Autoparte> listaAutopartes = getAutopartes();
        for (Autoparte autopartes : listaAutopartes) {
            if (autopartes.getIdProducto().equals(idProducto)) {
                return autopartes; 
            }
        }
        return null;
    } 
    
    public void modificacionDeProducto(String idProducto, Autoparte productoModificado) throws Exception {
        for (int i = 0; i < autopartes.size(); i++) {
            if (autopartes.get(i).getIdProducto().equals(idProducto)) {
                autopartes.set(i, productoModificado);
                return;
            }
        }
        throw new Exception("Producto no encontrado para modificar.");
    }
    
     public void bajaDeProductos(String idProducto) throws Exception {
        boolean removed = autopartes.removeIf(producto -> producto.getIdProducto().equals(idProducto));
        if (!removed) {
            throw new Exception("Producto no encontrado para dar de baja.");
        }
    }
     
     
    public ArrayList<Autoparte> listarProductosConStockMinimo() {
        ArrayList<Autoparte> productosConStockMinimo = new ArrayList<>();
        for (Autoparte autoparte : autopartes) {
            if (autoparte.VerificarStockMinimo()) {
                productosConStockMinimo.add(autoparte);
            }
        }
        return productosConStockMinimo;
    }
    
  //-------------------------------------------------------------------------------------------------------------------//

    public void listadoDeUsers() {
    	for (Cliente client : clientes) {
    		System.out.println(client);
    	}
    }
    
    public Cliente buscarCliente(String idCliente) {
    	ArrayList <Cliente> clientes = getClientes();
    	for (Cliente cliente: clientes) {
    		if(cliente.getIdCliente().equals(idCliente)) {
    			return cliente;
    		}
    	}
    	return null;
    }

    
    public void modificacionDeUser(String idCliente, Cliente clienteModificado) throws Exception {
        for (int i = 0; i < clientes.size(); i++) {
            if (clientes.get(i).getIdCliente().equals(idCliente)) {
                clientes.set(i, clienteModificado);
                return;
            }
        }
        throw new Exception("Usuario no encontrado para modificar.");
    }
    
  //-------------------------------------------------------------------------------------------------------------------//
    
    public Pedido buscarPedido(String idPedido) {
    	ArrayList<Pedido> pedidos = getPedidos();
    	for (Pedido pedido: pedidos) {
    		if (pedido.getIdPedido().equals(idPedido)) {
    			return pedido;
    		}
    	}
    	return null;
    }
    
    public void listadoDePedidos() {
   	 for (Pedido pedido: pedidos) {
   		 System.out.println(pedido);
   	 }
    }
    
    public void modificacionDePedido(String idPedido, Pedido pedidoModificado) throws Exception {
        for (int i = 0; i < pedidos.size(); i++) {
            if (pedidos.get(i).getIdPedido().equals(idPedido)) {
                pedidos.set(i, pedidoModificado);
                return;
            }
        }
        throw new Exception("Pedido no encontrado para modificar.");
    }
    
    public void eliminarPedido(String idPedido) throws Exception {
        boolean removed = pedidos.removeIf(pedido -> pedido.getIdPedido().equals(idPedido));
        if (!removed) {
            throw new Exception("Pedido no encontrado para eliminar.");
        }
    }
    
  //-------------------------------------------------------------------------------------------------------------------//    
    
    public Venta buscarVenta(String idVenta) {
    	ArrayList<Venta> ventas = getVentas();
    	for (Venta venta: ventas) {
    		if(venta.getIdVenta().equals(idVenta)) {
    			return venta;
    		}
    	}
    	return null;
    }
    
    public void listadoDeVentas() {
    	for (Venta venta: ventas) {
    		System.out.println(venta);
    	}
    }
    
  
    public void modificacionDeVenta(String idVenta, Venta ventaModificada) throws Exception {
        for (int i = 0; i < ventas.size(); i++) {
            if (ventas.get(i).getIdVenta().equals(idVenta)) {
                ventas.set(i, ventaModificada);
                return;
            }
        }
        throw new Exception("Venta no encontrada para modificar.");
    }

    public void eliminarVenta(String idVenta) throws Exception {
        boolean removed = ventas.removeIf(venta -> venta.getIdVenta().equals(idVenta));
        if (!removed) {
            throw new Exception("Venta no encontrada para eliminar.");
        }
    }
	
	public void listadoPedidos(String idCliente) {
		ArrayList<Pedido> lista = new ArrayList<>();
		for(Pedido pedido: pedidos) {
			if(pedido.idCliente.equals(idCliente) ) {
				lista.add(pedido);
			}
		}
		
		 for (Pedido listas : lista) {
			 System.out.println(listas);
	        }
	}

//-------------------------------------------------------------------------------------------------------------------//    

 /*   public void registrarVentaDesdePedido(Pedido pedido) {
        // Crear una nueva venta a partir del pedido
        String idVenta = "V-" + pedido.getIdPedido(); // Generar un ID de venta basado en el ID del pedido
        String metodoPago = "Efectivo"; // Asignar un método de pago por defecto o preguntarle al usuario
        float precio = pedido.getTotal();

        Venta venta = new Venta(idVenta, metodoPago, precio, idPedido, cantidad);
        ventas.add(venta);

        System.out.println("Venta registrada desde pedido con éxito.");
    }    */
 
}
